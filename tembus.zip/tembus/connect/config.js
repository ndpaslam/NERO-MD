const fs = require('fs')
const chalk = require('chalk')

// ganti aja gpp
global.ownerName = "Mr4slam"
global.ownerNumber = "6285893523975"
global.botName = "MR4"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})